package sk.itvkurze.zadanie26_4;

public interface Meratelne {
	double getHodnota();

}
