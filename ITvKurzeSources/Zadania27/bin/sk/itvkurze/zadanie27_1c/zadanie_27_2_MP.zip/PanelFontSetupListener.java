package sk.itvkurze.zadanie27_1c;

import java.util.EventListener;

public interface PanelFontSetupListener extends EventListener
{
	public void occuredPanelEvent(PanelFontSetupEvent event);
}
