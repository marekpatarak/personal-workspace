package sk.itvkurze.zadanie27_1d;

import java.util.EventListener;

public interface PanelFontSetupListener extends EventListener
{
	public void occuredPanelEvent(PanelFontSetupEvent event);
}
