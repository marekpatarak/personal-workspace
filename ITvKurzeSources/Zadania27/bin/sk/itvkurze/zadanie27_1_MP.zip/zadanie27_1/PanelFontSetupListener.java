package sk.itvkurze.zadanie27_1;

import java.util.EventListener;

public interface PanelFontSetupListener extends EventListener
{
	public void occuredPanelEvent(PanelFontSetupEvent event);
}
