package sk.itvkurze.zadania05;

public class BankovyUcetTester {

	public static void main(String[] args) {
		BankovyUcet novyUcet = new BankovyUcet();
		System.out.println("Stav uctu je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 0");

		// vklad na novyUcet 1000 EUR a zauctovanie poplatku
		novyUcet.vkladUcet(1000);
		System.out.println("Stav uctu po vklade je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu po vklade je: 999");

		// zapis uroku 10 percent
		novyUcet.zapisUrok(10);
		System.out.println("Stav uctu po zapise uroku je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 1098,90");

		// zapis uroku 10 percent
		novyUcet.zapisUrok(10);
		System.out.println("Stav uctu po zapise uroku je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 1208,79");

		// vyber z uctu 200 EUR a zauctovanie poplatku
		novyUcet.vyberUcet(200);
		System.out.println("Stav uctu po vybere je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu po vklade je: 1006,79");

	}

}
