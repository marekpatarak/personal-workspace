package sk.itvkurze.zadania05;

public class BankovyUcet {
	private double stavUctu;

	public double getStavUctu() {
		return stavUctu;
	}

	public void vkladUcet(double vklad) {
		this.stavUctu += vklad;
		this.zauctujPoplatok(1);
	}

	public void vyberUcet(double vyber) {
		this.stavUctu -= vyber;
		this.zauctujPoplatok(2);
	}

	private void zauctujPoplatok(double poplatok) {
		this.stavUctu -= poplatok;
	}

	public void zapisUrok(double sadzba) {
		this.stavUctu += this.stavUctu * sadzba / 100;
	}

}
