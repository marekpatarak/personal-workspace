package sk.itvkurze.zadania05;

import java.awt.Graphics2D;

public class Pismeno {
	protected int hornyRohX;
	protected int hornyRohY;
	protected int width;
	protected int height;

	protected Pismeno(int x, int y, int width, int height) {
		this.hornyRohX = x;
		this.hornyRohY = y;
		this.width = width;
		this.height = height;
	}

	protected void nakresli(Graphics2D g2) {

	}

}
