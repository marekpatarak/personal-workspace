package sk.itvkurze.zadania05;

public class BankovyUcetTester {

	public static void main(String[] args) {
		BankovyUcet novyUcet = new BankovyUcet();
		System.out.println("Stav uctu je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 0");

		// vklad na novyUcet 1000 EUR
		novyUcet.vkladUcet(1000);
		System.out.println("Stav uctu po vklade je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu po vklade je: 1000");

		// zapis uroku 10 percent
		novyUcet.zapisUrok(10);
		System.out.println("Stav uctu po zapise uroku je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 1100");

		novyUcet.zapisUrok(10);
		System.out.println("Stav uctu po zapise uroku je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 1210");

	}

}
