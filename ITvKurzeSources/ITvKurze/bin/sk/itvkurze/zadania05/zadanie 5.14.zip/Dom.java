package sk.itvkurze.zadania05;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Line2D;

public class Dom {
	private int x;
	private int y;

	public Dom(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public void nakresli(Graphics2D g2) {
		Rectangle dom = new Rectangle(this.x, this.y - 200, 200, 200);
		Rectangle okno = new Rectangle(this.x + 50, this.y - 100, 50, 50);
		Rectangle dvere = new Rectangle(this.x + 125, this.y - 100, 50, 100);

		g2.draw(dom);
		g2.draw(okno);
		g2.draw(dvere);

		Line2D.Double strecha1 = new Line2D.Double(this.x, this.y - 200, this.x + 100, this.y - 300);
		Line2D.Double strecha2 = new Line2D.Double(this.x + 200, this.y - 200, this.x + 100, this.y - 300);

		g2.draw(strecha1);
		g2.draw(strecha2);
	}
}
