package sk.itvkurze.zadania05;

import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JComponent;

public class KomponentaDom extends JComponent {
	@Override
	public void paintComponent(Graphics g) {

		Graphics2D g2 = (Graphics2D) g;

		Dom dom = new Dom(this.getWidth() / 4, this.getHeight() - 25);
		dom.nakresli(g2);

	}
}