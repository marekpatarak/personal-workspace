package sk.itvkurze.zadania05;

public class Auto {
	private double spotreba;
	private double stavNadrze;
	private double stavTachometra;

	public Auto(double spotreba) {
		this.stavNadrze = 0;
		this.stavTachometra = 0;
		this.spotreba = spotreba;
	}

	public double getStavNadrze() {
		return stavNadrze;
	}

	public double getStavTachometra() {
		return stavTachometra;
	}

	public void setSpotreba(double spotreba) {
		this.spotreba = spotreba;
	}

	public void natankuj(double tankovanie) {
		this.stavNadrze += tankovanie;
	}

	public void jazdi(double vzdialenost) {
		if (this.stavNadrze == 0) {
			System.out.println("nemas palivo, natankuj");
		} else {
			if (this.stavNadrze >= (this.spotreba * vzdialenost / 100)) {
				this.stavNadrze -= (this.spotreba * vzdialenost / 100);
				this.stavTachometra += vzdialenost;
			} else {
				System.out.println("Auto nepreslo " + vzdialenost + " kilometrov, minulo sa palivo po prejdeni "
					+ this.stavNadrze / this.spotreba * 100 + " kilometrov");
				this.stavTachometra += this.stavNadrze / this.spotreba * 100;
				this.stavNadrze = 0;
			}
		}

	}
}
