package sk.itvkurze.zadania05;

public class BankovyUcetTester {

	public static void main(String[] args) {
		BankovyUcet novyUcet = new BankovyUcet();
		System.out.println("Stav uctu je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 0");

		// vklad na novyUcet 1000 EUR
		novyUcet.vkladUcet(1000);
		System.out.println("Stav uctu po vklade je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 1000");

		// vyber z novyUcet 500 EUR
		novyUcet.vyberUcet(500);
		System.out.println("Stav uctu po vybere 500 je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 500");

		// vyber z novyUcet 400 EUR
		novyUcet.vyberUcet(400);
		System.out.println("Stav uctu po vybere 400 je: " + novyUcet.getStavUctu());
		System.out.println("Ocakavany stav uctu je: 100");

	}

}
