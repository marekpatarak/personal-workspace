package sk.itvkurze.zadania05;

public class BankovyUcet {
	private double stavUctu;

	public double getStavUctu() {
		return stavUctu;
	}

	public void vkladUcet(double vklad) {
		this.stavUctu += vklad;
	}

	public void vyberUcet(double vyber) {
		this.stavUctu -= vyber;
	}

}
