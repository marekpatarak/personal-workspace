package sk.itvkurze.zadanie7_3;

public class GeneratorTester {

	public static void main(String[] args) {

		Generator generator = new Generator();
		generator.generuj(10, 12);
		generator.generuj(2, 12);
	}

}
